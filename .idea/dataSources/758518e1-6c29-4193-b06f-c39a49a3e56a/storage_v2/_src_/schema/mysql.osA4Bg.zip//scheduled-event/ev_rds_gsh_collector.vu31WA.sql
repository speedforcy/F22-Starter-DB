create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2022-09-28 18:14:59'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

